TO RUN:
In terminal, type:
python naivebayes.py training-clean.csv test-clean.csv

*This will generate a file called result.csv, which contains the predictions.
*NOTE that every time you run this code, make sure you delete pre-generated result.csv