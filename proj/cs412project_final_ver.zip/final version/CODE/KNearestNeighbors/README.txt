TO RUN:
python main.py

*predictions are in result.csv