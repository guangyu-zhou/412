#ifndef PARSE_H
#define PARSE_H
#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <sstream>
#include <map>
#include "parse.cpp"

map<int, string> parse(); // function prototype for add.h


#endif
